package com.tiendaweb.controller;

import com.tiendaweb.service.PedidoService;
import com.tiendaweb.model.DatosPago;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/pedido")
public class PedidoController {

    @Autowired
    private PedidoService pedidoService;

    @PostMapping("/compra")
    public ResponseEntity<String> comprar(@RequestBody DatosPago pago) {
        if(pago.esValido()) {
            pedidoService.registrarPedido(pago);
            return ResponseEntity.ok("Compra completada");
        }
        return ResponseEntity.badRequest().body("Pago rechazado");
    }
}