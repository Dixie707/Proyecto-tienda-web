package com.tiendaweb.controller;

import com.tiendaweb.model.Usuario;
import com.tiendaweb.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService service;

    @PostMapping("/registro")
    public ResponseEntity<String> registrar(@RequestBody Usuario u) {
        return ResponseEntity.ok(service.registrar(u));
    }

    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody Usuario u) {
        return ResponseEntity.ok(service.login(u));
    }
}