package com.tiendaweb.controller;

import com.tiendaweb.model.Producto;
import com.tiendaweb.Repository.ProductoRepository;
import com.tiendaweb.service.CarritoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/carrito")
public class CarritoController {

    @Autowired
    private ProductoRepository productoRepo;

    @Autowired
    private CarritoService carritoService;

    @PostMapping("/agregar/{idProducto}")
    public ResponseEntity<String> agregar(@PathVariable Long idProducto) {
        Producto p = productoRepo.findById(idProducto).orElse(null);
        if(p == null || p.getStock() <= 0) {
            return ResponseEntity.ok("No hay disponibilidad");
        }
        carritoService.agregarProducto(p);
        return ResponseEntity.ok("Producto agregado correctamente");
    }
}