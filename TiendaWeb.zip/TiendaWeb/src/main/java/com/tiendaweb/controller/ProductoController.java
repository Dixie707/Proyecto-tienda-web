package com.tiendaweb.controller;

import com.tiendaweb.model.Producto;
import com.tiendaweb.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService service;

    @GetMapping
    public ResponseEntity<?> verCatalogo() {
        List<Producto> productos = service.verCatalogo();
        if(productos.isEmpty()) {
            return ResponseEntity.ok("No hay productos disponibles");
        }
        return ResponseEntity.ok(productos);
    }
}