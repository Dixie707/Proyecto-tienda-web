package com.tiendaweb.model;

public class DatosPago {
    private String tarjeta;
    private String nombreTitular;
    private String fechaExpiracion;
    private String cvv;

   
    public boolean esValido() {
        return tarjeta != null && cvv != null && nombreTitular != null && fechaExpiracion != null;
    }

    
    public String getTarjeta() {
        return tarjeta;
    }

    public void setTarjeta(String tarjeta) {
        this.tarjeta = tarjeta;
    }

    public String getNombreTitular() {
        return nombreTitular;
    }

    public void setNombreTitular(String nombreTitular) {
        this.nombreTitular = nombreTitular;
    }

    public String getFechaExpiracion() {
        return fechaExpiracion;
    }

    public void setFechaExpiracion(String fechaExpiracion) {
        this.fechaExpiracion = fechaExpiracion;
    }

    public String getCvv() {
        return cvv;
    }

    public void setCvv(String cvv) {
        this.cvv = cvv;
    }
}